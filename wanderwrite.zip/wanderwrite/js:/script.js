document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("contactForm");
    const response = document.getElementById("formResponse");
  
    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
  
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();
  
        if (!name || !email || !message) {
          response.style.color = "red";
          response.textContent = "Please fill in all fields.";
          return;
        }
  
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          response.style.color = "red";
          response.textContent = "Please enter a valid email address.";
          return;
        }
  
        response.style.color = "green";
        response.textContent = `Thank you, ${name}! Your message has been sent.`;
        form.reset();
      });
    }
  });
  